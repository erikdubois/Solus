/* LBM_PAPER_NOT_SET */
gchar *s = N_("The paper is not set correctly.");
/* LBM_COVER_OPEN */
gchar *s = N_("The printer cover is open.");
/* LBM_JAM */
gchar *s = N_("A paper jam has occurred.");
/* LBM_CHK_PRINTER */
gchar *s = N_("Check the printer.");
/* LBM_ERROR_CODE */
gchar *s = N_("Support Code: %s");
/* LBM_PREPARING */
gchar *s = N_("Preparing for printing...");
/* LBM_CANT_COMM_PRINT */
gchar *s = N_("Cannot communicate with the printer.");
/* LBM_BUSY */
gchar *s = N_("The printer is busy.");
/* LBM_PRINTING */
gchar *s = N_("Printing...");
